========================================================================
    DYNAMIC LINK LIBRARY : Org.Apache.Qpid.Messaging Project Overview
========================================================================

AppWizard has created this Org.Apache.Qpid.Messaging DLL for you.

This file contains a summary of what you will find in each of the files that
make up your Org.Apache.Qpid.Messaging application.

Org.Apache.Qpid.Messaging.vcproj
    This is the main project file for VC++ projects generated using an Application Wizard.
    It contains information about the version of Visual C++ that generated the file, and
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

Connection.[cpp h]
Duration.[cpp h]
Message.[cpp h]
Receiver.[cpp h]
Sender.[cpp h]
Session.[cpp h]
    Managed code Interop layer modules to provide access to functions exported by
    qpidcommon.dll.

AssemblyInfo.cpp
    Contains custom attributes for modifying assembly metadata.

/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" to indicate parts of the source code you
should add to or customize.

Current TODOs include:

 * Add locking as needed
 * Add remaining modules and methods
 * Capture and repackage exceptions emitted from messaging DLLs

/////////////////////////////////////////////////////////////////////////////
