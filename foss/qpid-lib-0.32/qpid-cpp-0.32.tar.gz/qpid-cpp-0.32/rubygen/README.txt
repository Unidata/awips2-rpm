RUBY CODE GENERATOR

Run ./generate for usage.
Examples in samples/

For example:
 ./generate . ../../specs/amqp.0-9.xml samples/Proxy.rb 
will generate









