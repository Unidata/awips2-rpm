/* <<< Release Notice for library >>> */

#include <projects.h>

char const pj_release[]="Rel. 4.9.3, 15 August 2016";

const char *pj_get_release()

{
    return pj_release;
}
