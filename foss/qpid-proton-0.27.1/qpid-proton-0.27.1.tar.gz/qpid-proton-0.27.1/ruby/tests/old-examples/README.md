# OLD EXAMPLES FOR BACKWARDS COMPATIBILITY TESTING

These examples are from 0.18.1, before the ruby IO refactoring.

They are run as part of the regression test suite to catch breaks in backwards
compatibility.

They will be removed when all deprecated features have been removed.
