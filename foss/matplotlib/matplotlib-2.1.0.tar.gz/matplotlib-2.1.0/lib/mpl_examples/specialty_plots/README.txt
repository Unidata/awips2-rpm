.. _specialty_plots_examples:

Specialty Plots
===============
