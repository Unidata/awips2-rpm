.. _pyplots_examples:

Pyplot Examples
===============
