.. _recipes:

Our Favorite Recipes
====================

Here is a collection of short tutorials, examples and code snippets
that illustrate some of the useful idioms and tricks to make snazzier
figures and overcome some matplotlib warts.
