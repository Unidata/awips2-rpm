**************
I/O with NumPy
**************

.. toctree::
   :maxdepth: 2

   basics.io.genfromtxt
