===================
Releasing a Version
===================

------------------------
How to Prepare a Release
------------------------

.. include:: ../../HOWTO_RELEASE.rst.txt

-----------------------
Step-by-Step Directions
-----------------------

.. include:: ../../RELEASE_WALKTHROUGH.rst.txt

