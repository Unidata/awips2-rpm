==========================
NumPy 1.xx.x Release Notes
==========================


Highlights
==========


New functions
=============


New deprecations
================


Expired deprecations
====================


Future changes
==============


Compatibility notes
===================


C API changes
=============


New Features
============


Improvements
============


Changes
=======
