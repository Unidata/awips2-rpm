# encoding: koi8-r
# mode: run
# ticket: 740
"""
>>> wtf
'wtf'
"""

wtf = 'wtf'
