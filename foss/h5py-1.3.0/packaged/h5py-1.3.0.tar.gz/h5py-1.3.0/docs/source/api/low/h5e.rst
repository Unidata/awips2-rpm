Module H5E
==========

.. automodule:: h5py.h5e

.. autoclass:: H5Error

.. autofunction:: verbose
.. autofunction:: register_thread
.. autofunction:: unregister_thread
