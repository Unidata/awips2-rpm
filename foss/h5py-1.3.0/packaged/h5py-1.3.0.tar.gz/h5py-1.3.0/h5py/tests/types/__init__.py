
"""
    Type and data-conversion test package.

    Tests the following:

    1) HDF5 to NumPy type mapping
    2) Data conversion
"""
