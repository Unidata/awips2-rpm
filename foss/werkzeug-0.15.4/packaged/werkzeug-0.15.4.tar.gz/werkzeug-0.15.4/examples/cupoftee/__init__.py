# -*- coding: utf-8 -*-
"""
    cupoftee
    ~~~~~~~~

    Werkzeug powered Teeworlds Server Browser.

    :copyright: 2007 Pallets
    :license: BSD-3-Clause
"""
from .application import make_app
