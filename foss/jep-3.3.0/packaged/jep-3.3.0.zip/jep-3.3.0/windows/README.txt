This directory is for building Jep inside of Visual Studio.  It should be
considered as obsolete/deprecated since setup.py build now works with windows.