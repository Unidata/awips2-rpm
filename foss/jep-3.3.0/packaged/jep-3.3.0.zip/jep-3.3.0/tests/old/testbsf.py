from jep import *
import jep

print dir()
print dir(bsf)

a = 5
