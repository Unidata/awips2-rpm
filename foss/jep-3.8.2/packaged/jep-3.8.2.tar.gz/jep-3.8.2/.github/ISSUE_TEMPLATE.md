- OS Platform, Distribution, and Version:
- Python Distribution and Version:
- Java Distribution and Version:
- Jep Version:
- Python packages used (e.g. numpy, pandas, tensorflow):

