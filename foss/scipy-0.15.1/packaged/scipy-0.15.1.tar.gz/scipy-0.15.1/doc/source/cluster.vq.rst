.. automodule:: scipy.cluster.vq
