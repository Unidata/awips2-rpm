.. automodule:: scipy.linalg.lapack
