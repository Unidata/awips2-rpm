.. automodule:: scipy.sparse.linalg
