# -*- coding: utf8 -*-

test_text_for_utf8 = 'марко'
test_text_for_utf16 = 'ǰ捁楴敶免'