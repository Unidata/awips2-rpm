# -*- coding: utf8 -*-

test_text_for_utf8 = u'марко'
test_text_for_utf16 = u'ǰ捁楴敶免'