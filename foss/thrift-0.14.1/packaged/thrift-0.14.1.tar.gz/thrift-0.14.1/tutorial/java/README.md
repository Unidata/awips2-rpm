Thrift Java Tutorial
==================================================
1) Compile the Java library

    thrift/lib/java$ make
or:

    thrift/lib/java$ ant

4) Run the tutorial:

start server and client with one step:

    thrift/tutorial/java$ make tutorial

or:

    thrift/tutorial/java$ make tutorialserver
    thrift/tutorial/java$ make tutorialclient

or:

    thrift/tutorial/java$ ant tutorialserver
    thrift/tutorial/java$ ant tutorialclient
