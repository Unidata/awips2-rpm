-- Cleanup
DELETE FROM spatial_ref_sys;
