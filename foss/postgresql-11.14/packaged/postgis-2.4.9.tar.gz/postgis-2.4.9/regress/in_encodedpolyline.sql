select 'linefromencodedpolyline_01',st_asewkt(st_linefromencodedpolyline('_p~iF~ps|U_ulLnnqC_mqNvxq`@'));
select 'linefromencodedpolyline_02',st_asewkt(ST_SnapToGrid(st_linefromencodedpolyline('_izlhAj}oidF{}jgCrotj@chtxCn`{nI', 6),0.001));
