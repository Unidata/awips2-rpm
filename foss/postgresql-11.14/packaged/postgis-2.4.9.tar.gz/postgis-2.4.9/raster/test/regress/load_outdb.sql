SELECT count(*) FROM raster_outdb_template;
