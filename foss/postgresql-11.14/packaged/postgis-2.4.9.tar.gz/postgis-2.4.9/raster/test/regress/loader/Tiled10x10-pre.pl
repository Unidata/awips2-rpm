link "loader/testraster.tif", "loader/Tiled10x10.tif";
