link "loader/testraster.tif", "loader/Tiled8x8.tif";
