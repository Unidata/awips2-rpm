Samples files
-------------

Pointed out by Brad Hards:
https://github.com/codice/imaging-nitf/tree/master/shared-test-resources/src/main/resources
