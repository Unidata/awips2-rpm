select ST_Asewkt(the_geom) from loadedshp;

