select ST_Asewkt(the_geom::geometry) from loadedshp ORDER BY gid;

