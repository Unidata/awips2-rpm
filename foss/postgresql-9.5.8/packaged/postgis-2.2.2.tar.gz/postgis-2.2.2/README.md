Travis:
 [![Build Status](https://secure.travis-ci.org/postgis/postgis.png?branch=svn-2.2)]
 (http://travis-ci.org/postgis/postgis)
Debbie:
 [![Build Status](http://debbie.postgis.net:8080/buildStatus/icon?job=PostGIS_2.2)]
 (http://debbie.postgis.net:8080/view/PostGIS/job/PostGIS_2.2/)
Winnie:
 [![Build Status](http://winnie.postgis.net:1500/buildStatus/icon?job=PostGIS_2.2)]
 (http://winnie.postgis.net:1500/view/PostGIS/job/PostGIS_2.2/)
GitLab-CI:
 [![Build Status](http://gitlab.com/ci/projects/3944/status.png?ref=svn-2.2)]
 (http://gitlab.com/ci/projects/3944?ref=svn-2.2)

This file is here to play nicely with modern code repository facilities.
Actual readme is [here](README.postgis).

## Official code repository, issue tracker and wiki:
https://trac.osgeo.org/postgis/

## Official source tarball releases
http://postgis.net/source

If you would like to contribute to this project, please refer to our
[contributing guidelines](CONTRIBUTING.md).

## Project Home Page and Manuals
Project homepage: http://postgis.net/
PostGIS Manuals: http://postgis.net/documentation
