.. image:: https://img.shields.io/pypi/v/jaraco.functools.svg
   :target: https://pypi.org/project/jaraco.functools

.. image:: https://img.shields.io/pypi/pyversions/jaraco.functools.svg

.. image:: https://img.shields.io/travis/jaraco/jaraco.functools/master.svg
   :target: https://travis-ci.org/jaraco/jaraco.functools

.. .. image:: https://img.shields.io/appveyor/ci/jaraco/jaraco-functools/master.svg
..    :target: https://ci.appveyor.com/project/jaraco-functools/skeleton/branch/master

.. image:: https://readthedocs.org/projects/jaracofunctools/badge/?version=latest
   :target: https://jaracofunctools.readthedocs.io/en/latest/?badge=latest

Additional functools in the spirit of stdlib's functools.