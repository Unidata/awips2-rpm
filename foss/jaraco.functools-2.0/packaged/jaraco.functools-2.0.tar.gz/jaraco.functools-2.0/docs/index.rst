Welcome to jaraco.functools documentation!
==========================================

.. toctree::
   :maxdepth: 1

   history


.. automodule:: jaraco.functools
    :members:
    :undoc-members:
    :show-inheritance:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

