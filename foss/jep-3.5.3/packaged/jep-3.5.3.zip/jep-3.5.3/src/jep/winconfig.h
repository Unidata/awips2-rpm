
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#define R_OK 4
#define F_OK 0

/* Define if you want to deallocate objects. */
#define USE_DEALLOC 1
