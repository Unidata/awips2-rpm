# -*- coding: utf-8 -*-

########################################################################
#
# License: BSD
# Created: 2007-01-18
# Author:  Ivan Vilata i Balaguer - ivan@selidor.net
#
# $Id$
#
########################################################################

"""Unit tests for special node behaviours."""
