This directory contains registry updates to allow MS Visual Studio 2008 64-bit
builds to work on Appveyor.

See: https://help.appveyor.com/discussions/kb/38-visual-studio-2008-64-bit-builds

Source: https://github.com/menpo/condaci/blob/master/vs2008_patch.zip
