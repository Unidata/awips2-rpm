Module H5D
==========

.. automodule:: h5py.h5d
    :members:

Module constants
----------------

.. _ref.h5d.ALLOC_TIME:

Allocation times
~~~~~~~~~~~~~~~~

.. data:: ALLOC_TIME_DEFAULT
.. data:: ALLOC_TIME_LATE 
.. data:: ALLOC_TIME_EARLY
.. data:: ALLOC_TIME_INCR  

