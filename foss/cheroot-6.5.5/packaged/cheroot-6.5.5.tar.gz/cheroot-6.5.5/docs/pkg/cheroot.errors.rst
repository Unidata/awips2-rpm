``cheroot.errors`` module
~~~~~~~~~~~~~~~~~~~~~~~~~

.. automodule:: cheroot.errors
    :members:
    :undoc-members:
    :show-inheritance:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
