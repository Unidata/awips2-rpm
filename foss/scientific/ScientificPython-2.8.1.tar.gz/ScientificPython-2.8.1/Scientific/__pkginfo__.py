# Data used both in the package and by setup.py

__version__ = '2.8.1'
